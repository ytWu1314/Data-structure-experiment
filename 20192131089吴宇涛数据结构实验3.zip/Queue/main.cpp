﻿#include"Queue.h"
#include "Stack.h"
#include <iostream>
using namespace std;
int n;
void Menu() {
	cout << "-----------------------菜单-------------------------" << endl;
	cout << "1.汽车到达   2.汽车离开   3.输出停车中的所有汽车牌号" << endl;
	cout << "4.输出候车场中的所有汽车牌号          5.退出系统运行" << endl;
	cout << "----------------------------------------------------" << endl;
}
int main()
{
	puts("请输入停车场内能停放汽车的数量：");
	cin >> n;  //停车场最大能停放汽车的数量
	seqstack <int> a(n);
	SeqQueue<int> b(1000);
	int p;
	Menu();
	while (cin >> p) {
		
		switch (p)
		{
		case 1:
		{
			puts("请输入到达汽车的数量");
			int  s;
			cin >> s; //到达汽车的数量 如过s>n 
			//超过停车场承载的汽车进入候车场
			a.getmaxsize(n);
			int x;

			//如果汽车的数量没有超过停车场的承载直接压入栈里
			puts("请输入达到汽车的车牌号码");
			if (s < n)
			{
				for (int i = 0; i < s; i++)
				{
					cin >> x;
					a.push(x);
				}
			}
			else if (s > n)
			{
				for (int i = 0; i < s; i++)
				{
					cin >> x;
					if (!a.IsFull())
						a.push(x);
					if (a.IsFull())
					{
						//超过停车场承载 进入候车场队列
						b.EnQueue(x);
					}
				}
			}
			Menu();
			break;
		}
		case 2: {
			int z;
			if (!a.IsEmpty())
				//cout << "停车场离开的汽车车牌号码为:" << a.getTop() << endl;
				//a.Pop();
			puts("请输入离开的汽车的序号:(第一个入停车场的为1号)");
			cin >>z;
			z -= 1;
			puts("请输入停留时间");
			int Time;
			cin >> Time;
			a.temppop(a, z,Time ); //临时栈 将退出停车场的前面的车压进一个临时栈里
			if (!a.IsFull())
			{
				puts("候车场的车辆进入");
				a.push(b.getFront());  //退出来的车 可以让候车场的车进去
				b.DeQueue();  //队头出队 压进栈里
			}
			if (a.IsEmpty())
			{
				//如果栈：停车场为空 候车场的车离开
				b.DeQueue(); 
			}		
			Menu();
			break;
		}
		case 3:
		{
			int t = a.top;
			if (t <0)
			{
				puts("停车场为空");
				break;
			}
			puts("输出停车场中所有汽车牌号:");
			for (int i = t; i >=0; i--)   //遍历停车场栈 将栈里的汽车弹出
			{
				cout << "停车的位置"<<i+1<< ":  " << a.elements[i] << " " << endl;
				//a.Pop();
			}
			puts("");
			Menu();
			break;
		}
		case 4: {
			if (b.rear == 0) {
				puts("候车场为空");
				break;
			}

			puts("输出候车场中的所有汽车牌号: ");
			int t = b.rear;
			for (int i = b.front+1; i < t; i++)
			{
				//遍历候车场里所有的车 将候车场队列里的车全部弹出
				cout <<i<<" : "<< b.Elements[i] << endl;
				//b.DeQueue();
			}
			puts("");
			Menu();
			break;
		}
		case 5: {
			puts("退出系统运行!");
			return 0;
		}
		}
	}
	return 0;
}