#include "seqlist.h"
#include "ui_seqlist.h"
#include <QFile>
#include <QFileDialog>


seqlist::seqlist(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::seqlist)
{
    ui->setupUi(this);
}

seqlist::~seqlist()
{
    delete ui;
}


void seqlist::on_pushButton_clicked()
{
    //定义路径
    QString path =QFileDialog ::getOpenFileName(this,
                                                "open","../","TXT(*.txt)");
    if(path.isEmpty()==false)
    {
        //文件对象
        QFile file(path);

        //打开文件，只读方式
        bool isok=file.open(QIODevice::ReadOnly);

        if(isok)
        {
            //读文件，默认识别utf8编码
            QByteArray array= file.readAll();

            //显示到编辑区
            ui->textEdit->setText(array);
        }
        //关闭文件
        file.close();
    }


}

void seqlist::on_pushButton_2_clicked()
{
    QString path =QFileDialog::getSaveFileName(this,"save","../","TXT(*.txt)");
    if(path.isEmpty()==false )
    {
        QFile file (path); //创建文件对像，关联文件名字

        bool isok= file.open(QIODevice::WriteOnly); //打开文件，只写方式

        if(isok)
        {
            QString str= ui->textEdit->toPlainText();  //获取编辑区的内容
            file.write(str.toUtf8()); //获取完之后就写，并且转化成为utf8编码

        }
        file.close();
    }
}
