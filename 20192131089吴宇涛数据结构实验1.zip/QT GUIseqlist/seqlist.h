#ifndef SEQLIST_H
#define SEQLIST_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class seqlist; }
QT_END_NAMESPACE

class seqlist : public QMainWindow
{
    Q_OBJECT

public:
    seqlist(QWidget *parent = nullptr);
    ~seqlist();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::seqlist *ui;
};
#endif // SEQLIST_H
