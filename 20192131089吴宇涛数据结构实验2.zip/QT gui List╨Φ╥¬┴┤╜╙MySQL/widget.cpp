#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlDriver>
#include <QtSql/QSqlError>
#include <QMessageBox>
#include <QtSql>
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QFileSystemModel>
#include <QFile>
#include <QSqlQuery>
#include <QPainter>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    qDebug()<<QSqlDatabase::drivers();
    QSqlDatabase db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("127.0.0.1");
    db.setUserName("root");
    db.setPassword("123456");
    db.setDatabaseName("info");


    if(!db.open()){
        QMessageBox::warning(this,"错误",db.lastError().text());
        return ;
    }
    model =new QSqlTableModel(this);
    model->setTable("studenthealth"); //指定使用哪个表

    //把model放到view里面

    ui->tableView->setModel(model);

    //显示model数据
    model->select();


    //widget中栏目显示的内容，不会影响到数据库
    model->setHeaderData(0,Qt::Horizontal,"序号");
    model->setHeaderData(1,Qt::Horizontal,"学号");
    model->setHeaderData(2,Qt::Horizontal,"姓名");
    model->setHeaderData(3,Qt::Horizontal,"出生年份");
    model->setHeaderData(4,Qt::Horizontal,"性别");
    model->setHeaderData(5,Qt::Horizontal,"班级");
    model->setHeaderData(6,Qt::Horizontal,"健康状况");

    //设置model的编辑模式，手动提交修改
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
}

Widget::~Widget()
{
    delete ui;
}

//增加按钮
void Widget::on_pushButton_clicked()
{

    //添加空记录

    QSqlRecord record= model->record();

    //获取行号

    int row =model->rowCount();
    model->insertRecord(row,record);

}

//确定按钮
void Widget::on_pushButton_3_clicked()
{
    model->submitAll();
}

//取消按钮
void Widget::on_pushButton_4_clicked()
{
    model->revertAll();
    model->submitAll();
}

void Widget::on_pushButton_2_clicked()
{
    //获取选中的模型
   QItemSelectionModel *sModel= ui->tableView->selectionModel();
   //取出模型中的索引

   QModelIndexList list=sModel->selectedRows();

   //删除选中的行
   for(int i=0;i<list.size();i++)
   {
       model->removeRow(list.at(i).row());
   }

}


void Widget::on_pushButton_6_clicked()
{
    QString StudentNum= ui->lineEdit->text();
    QString str=QString("StudentNum= '%1'").arg(StudentNum);
    model->setFilter(str);
    model->select();

}

void Widget::paintEvent(QPaintEvent *)
{
    QPainter p;
    p.begin(this);

    p.drawPixmap(0,0,width(),height(),QPixmap("../1234.jpg"));
    p.end();
}
