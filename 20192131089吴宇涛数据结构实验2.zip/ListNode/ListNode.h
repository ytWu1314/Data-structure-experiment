#pragma once
#include<iostream>
using namespace std;
//����ṹ��:LinkNode  
template <class T>
struct LinkNode{
	T val;
	LinkNode<T>* next;
	LinkNode(LinkNode<T>* ptr = NULL) { next = ptr; } //���캯��
	LinkNode(const T& item, LinkNode<T>* ptr = NULL) {
		val = item; next = ptr;
	}
};
template<class T>
class List {
public:
	LinkNode<T>* first; //ͷ�ڵ�
	List() { first = new LinkNode<T>; } //���캯��
	List(const T& x) { first = new LinkNode<T>(x); } //���캯��
	List(List<T>& L);//���ƹ��캯��

	List(T* f, T* l) {
		first = new  LinkNode<T>;
		LinkNode<T>* tail = first;
		while (f != l) {
			LinkNode<T>* tmp = new LinkNode<T>(*f);
			++f;
			tail->next = tmp;
			tail = tail->next;
		} //���캯�� 
	}

	~List() { makeEmpty(); } //��������
	void makeEmpty(); //���������Ԫ��
	int Length() const;  //�����
	LinkNode<T>* getHead() const { return first; } //����ͷ�ڵ�
	void setHead(LinkNode<T>* p) { first = p; } //�趨ͷ�ڵ�
	bool  Search(T &x); //���������Ƿ���ڸ�Ԫ��
	LinkNode<T>* Locate(int i); //����Ԫ�����ڵĽ��
	T* getData(int i); 
	void setData(int i, T& x);
	bool Insert(int i, T& x);  //����Ԫ��
	void inputFront(T endTag); //ͷ�巨
 	void inputRear(T endTag); //β�巨
	bool Remove(int i);  //ɾ�����
	bool IsEmpty() const {
		return first->next == NULL ? true:false;
	} //�ж��Ƿ�Ϊ��
	bool IsFull() const {
		return false;
		//�жϱ��Ƿ���
	}
	void Sort();
	void input(); //��������Ԫ��
	void output(); //�������Ԫ��
	List<T>& operator =(List <T>& L);
	void Reverse();  //ת�ú���
	LinkNode<T>*  apart(); //�ֽ�����
	
};

template <class T>
List <T> ::List(List <T>& L) {
	T value;
	LinkNode<T>* srcptr = L.getHead();
	LinkNode<T>* desptr = first = new LinkNode<T>;
	while (srcptr->next != NULL)
	{
		value=srcptr->next->val;
		desptr->next = new LinkNode<T>(value);
		desptr = desptr->next;
		srcptr = srcptr->next;
	}
	desptr->next = NULL;
}
template <class T>
void List<T> ::makeEmpty()
{
	LinkNode<T>* q;
	while (first->next != NULL)
	{
		q = first->next;
		first->next = q->next;
		delete q;
	}
}
template <class T> 
int List <T> ::Length()const {
	LinkNode <T>* p = first->next;
	int cnt = 0;
	while (p != NULL)
	{
		p = p->next;
		cnt++;
	}
	return cnt;
}

template<class T>
bool  List <T>::Search(T &x)
{
	LinkNode <T>* cur = first->next;
	while (cur != NULL)
	{
		if (cur->val == x)
		{
			return true; break;
		}
		else cur = cur->next;
	}
	return 0;
}
template <class T>
LinkNode <T>* List <T> ::Locate(int i)
{
	if (i < 0) return NULL;
	LinkNode<T>* cur = first;
	int k = 0;
	while (cur != NULL && k < i)
	{
		cur = cur->next; k++;
	}
	return cur;
}
template <class T>
T* List <T> ::getData(int i)
{
	if (i <= 0) return -1;
	LinkNode<T>* cur = Locate(i);
	if (cur == NULL)return  -1 ;
	else return &cur->val;
}
template <class T>
void List <T>::setData(int i, T& x)
{
	if (i <= 0) return ;
	LinkNode <T>* cur = Locate(i);
	if (cur == NULL)return;
	else cur->val = x;
}
template <class T>
bool List<T> ::Insert(int i, T& x)
{
	LinkNode <T>* cur = Locate(i);
	if (cur == NULL)return false;
	LinkNode<T>* newNode = new LinkNode<T>(x);
	newNode->next = cur->next;
	cur->next = newNode;
	return true;
}
template <class T>
void List <T> ::inputFront(T endTag) {
	LinkNode <T>* newNode;
	T val;
	first = new LinkNode <T>;
	cin >> val;
	while (val != endTag) {
		newNode = new LinkNode <T>(val);
		newNode->next = first->next;
		first->next = newNode;
		cin >> val;
	}
}
template <class T>
void List <T>::inputRear(T endTag)
{
	LinkNode<T>* newNode, * last;
	T val;
	first = new LinkNode <T>;
	cin >> val;
	last = first;
	while (val != endTag)
	{
		newNode = new LinkNode<T>(val);
		last->next = newNode;
		last = newNode;
		cin >> val;
	}
	last->next = NULL;
}
template <class T>
bool List <T> ::Remove(int i)
{
	LinkNode <T>* cur = Locate(i - 1);
	LinkNode <T>* del = cur->next;
	cur->next = del->next;
	delete del;
	return true;
}
template <class T>
void List<T> ::output()
{
	LinkNode<T>* cur = first->next;
	while (cur != NULL)
	{
		cout << cur->val << " ";
		cur = cur->next;
	}
	puts("");
}
template <class T>
void List<T> ::Reverse()
{
	LinkNode<T>* pre;
	LinkNode <T>* cur;
	LinkNode <T>* tmp;
	cur = first->next;
	first->next = NULL;
	pre = NULL;
	while (cur)
	{
		tmp = cur->next;
		cur->next = pre;
		pre = cur;
		cur = tmp;
	}
	first->next = pre;
}
template<class T>
LinkNode<T>  * List <T>::apart()
{
	LinkNode<T>* cnr = first ;
	LinkNode<T>* first1 = new  LinkNode<T>;
	LinkNode<T>* tail1 = first1;
	while (cnr->next)
	{
		if ((cnr->next->val) % 2 == 0)
		{
			tail1->next = cnr->next;
			cnr->next = cnr->next->next;
			tail1 = tail1->next;
			tail1->next = 0;
		}
		else  cnr = cnr->next;
		
	}
	return first1;
}
/*
template<class T>
LinkNode<T>* List <T>::apart2()
{
	 LinkNode <T>*tmp= p1;
	LinkNode<T>* first2 = tmp;
	LinkNode<T>* First2 = first2;
	tmp = tmp->next;
	while (tmp)
	{
		if ((tmp->val) %2 == 0)
		{
			first2->next = tmp;
			first2 = first2->next;
		}
		tmp = tmp->next;
	}
	return First2;

}*/